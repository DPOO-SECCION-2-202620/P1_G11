package modelo;

import java.io.Serializable;

public class Compras implements Serializable {

	private static final long serialVersionUID = 1L;

	private Articulo articulo;

	private int cantidad;

	private double precioXunidad;

	public Compras(Articulo articulo, int cantidad, double precioXunidad) {
		this.articulo = articulo;
		this.cantidad = cantidad;
		this.precioXunidad = precioXunidad;
	}
}
